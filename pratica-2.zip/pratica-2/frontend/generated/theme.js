import {applyTheme as _applyTheme} from './theme-pratica2.generated.js';
export const applyTheme = _applyTheme;
