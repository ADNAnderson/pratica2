// @ts-nocheck
window.Vaadin = window.Vaadin || {};
window.Vaadin.featureFlags = window.Vaadin.featureFlags || {};
window.Vaadin.featureFlags.exampleFeatureFlag = false;
window.Vaadin.featureFlags.collaborationEngineBackend = false;
export {};