package com.example.application.data.entity;

import jakarta.persistence.Entity;

@Entity
public class Apartamentos extends AbstractEntity {

    private Integer apt_number;
    private String name;

    public Integer getApt_number() {
        return apt_number;
    }
    public void setApt_number(Integer apt_number) {
        this.apt_number = apt_number;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

}
