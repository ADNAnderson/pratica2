package com.example.application.views.home;

import com.example.application.views.MainLayout;
import com.example.application.views.edificio.EdificioView;
import com.vaadin.flow.component.Key;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.map.configuration.View;
//import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.router.RouteAlias;

@PageTitle("Home")
@Route(value = "home", layout = MainLayout.class)
@RouteAlias(value = "", layout = MainLayout.class)
public class HomeView extends HorizontalLayout {

    //private TextField name;
    private Button mostrarLista;
    private EdificioView edificio;

    public HomeView() {
        //name = new TextField("Your name");
        mostrarLista = new Button("Mostrar Apartamentos");
        mostrarLista.addClickListener(e -> {
            edificio = new EdificioView(null);
            dispose();
        });
        mostrarLista.addClickShortcut(Key.ENTER);

        setMargin(true);
        setVerticalComponentAlignment(Alignment.END, mostrarLista);

        add(mostrarLista);
    }

    private void dispose() {
    }

}
